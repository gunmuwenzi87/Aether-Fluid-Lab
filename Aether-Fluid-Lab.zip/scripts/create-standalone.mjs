import { readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDirectory = dirname(fileURLToPath(import.meta.url));
const outputDirectory = join(scriptDirectory, "..", "dist");
const sourcePath = join(outputDirectory, "index.html");
const html = await readFile(sourcePath, "utf8");
const stylesheetMatch = html.match(/<link[^>]+href="([^"]+\.css)"[^>]*>/i);
const scriptMatch = html.match(/<script[^>]+src="([^"]+\.js)"[^>]*><\/script>/i);

if (!stylesheetMatch || !scriptMatch) {
  throw new Error("The production HTML is missing its bundled stylesheet or script.");
}

const stylesheetPath = join(outputDirectory, stylesheetMatch[1].replace(/^\.\//, ""));
const scriptPath = join(outputDirectory, scriptMatch[1].replace(/^\.\//, ""));
const [stylesheet, script] = await Promise.all([readFile(stylesheetPath, "utf8"), readFile(scriptPath, "utf8")]);
const standalone = html
  .replace(stylesheetMatch[0], `<style>${stylesheet}</style>`)
  .replace(scriptMatch[0], `<script type="module">${script}</script>`);

await Promise.all([
  writeFile(join(outputDirectory, "Aether-Fluid-Lab.html"), standalone, "utf8"),
  writeFile(join(scriptDirectory, "..", "Aether-Fluid-Lab.html"), standalone, "utf8")
]);
