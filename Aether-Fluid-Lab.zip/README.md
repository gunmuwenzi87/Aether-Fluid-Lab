# Aether — 2D Fluid Lab

Aether is a compact fluid playground built with TypeScript, native CSS, and Canvas 2D. Paint a stream into the field and watch it curl, diffuse, and blend in real time. The app runs locally in the browser; no input or telemetry is sent anywhere.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. To create a portable, single-file preview, run `npm run build` and open `Aether-Fluid-Lab.html` directly. It runs without a server or external assets.

## Explore

- Drag across the canvas to inject colored dye and momentum.
- Tune brush size, flow strength, viscosity, and diffusion.
- Switch between four color fields; toggle soft glow, vortex brush, and ambient flow independently.
- Pause the solver or reset the canvas at any time.
- Switch between English and Simplified Chinese without reloading.

The simulation uses a grid-based stable-fluid solver with semi-Lagrangian advection, pressure projection, and iterative diffusion. Canvas resolution is adapted to the viewport and device pixel ratio. The page releases its animation frame, observers, event listeners, solver buffers, and offscreen canvas on teardown.

## Validation

```sh
npm run typecheck
npm run build
```
