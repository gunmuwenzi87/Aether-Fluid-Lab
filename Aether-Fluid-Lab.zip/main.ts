import "./style.css";

type Language = "en" | "zh";
type ThemeId = "aurora" | "prism" | "ember" | "lagoon";
type FieldKind = 0 | 1 | 2;
type ErrorKey = "canvasUnavailable" | "simulationFailure";

interface Messages {
  pageTitle: string;
  brandCaption: string;
  liveSimulation: string;
  switchLanguageTitle: string;
  eyebrow: string;
  headingLead: string;
  headingAccent: string;
  introDescription: string;
  introNote: string;
  noteIndex: string;
  panelKicker: string;
  controls: string;
  brushSection: string;
  brushSize: string;
  brushSizeTitle: string;
  flowForce: string;
  flowForceTitle: string;
  viscosity: string;
  viscosityTitle: string;
  diffusion: string;
  diffusionTitle: string;
  palette: string;
  paletteAria: string;
  themeAurora: string;
  themeAuroraTitle: string;
  themePrism: string;
  themePrismTitle: string;
  themeEmber: string;
  themeEmberTitle: string;
  themeLagoon: string;
  themeLagoonTitle: string;
  effects: string;
  glow: string;
  glowDetail: string;
  glowTitle: string;
  vortex: string;
  vortexDetail: string;
  vortexTitle: string;
  autoFlow: string;
  autoFlowDetail: string;
  autoFlowTitle: string;
  resetCanvas: string;
  resetTitle: string;
  resetNote: string;
  canvasOverline: string;
  canvasTitle: string;
  gridLabel: string;
  fpsLabel: string;
  pause: string;
  resume: string;
  pauseTitle: string;
  resumeTitle: string;
  canvasAria: string;
  canvasLive: string;
  dragHint: string;
  simulationRunning: string;
  simulationPaused: string;
  localRendering: string;
  footerMade: string;
  footerLine: string;
  dismissErrorTitle: string;
  workspaceAria: string;
  brandAria: string;
  canvasUnavailable: string;
  simulationFailure: string;
}

interface Color {
  readonly r: number;
  readonly g: number;
  readonly b: number;
}

interface Palette {
  readonly accent: string;
  readonly colors: readonly Color[];
}

interface FluidFields {
  u: Float32Array;
  v: Float32Array;
  u0: Float32Array;
  v0: Float32Array;
  red: Float32Array;
  green: Float32Array;
  blue: Float32Array;
  red0: Float32Array;
  green0: Float32Array;
  blue0: Float32Array;
  pressure: Float32Array;
  divergence: Float32Array;
}

const messages: Record<Language, Messages> = {
  en: {
    pageTitle: "Aether — 2D Fluid Lab",
    brandCaption: "A small study in motion",
    liveSimulation: "LIVE SIMULATION",
    switchLanguageTitle: "Switch to Simplified Chinese",
    eyebrow: "INTERACTIVE PHYSICS / 01",
    headingLead: "Make room for",
    headingAccent: "flow.",
    introDescription: "Paint a current. Watch color travel, fold, and find its own way.",
    introNote: "Every mark becomes part of the moving system.",
    noteIndex: "FIELD NOTE / 001",
    panelKicker: "THE INSTRUMENTS",
    controls: "Controls",
    brushSection: "Brush & flow",
    brushSize: "Brush size",
    brushSizeTitle: "Adjust the diameter of each brush stroke",
    flowForce: "Flow strength",
    flowForceTitle: "Control how much momentum a brush stroke adds",
    viscosity: "Viscosity",
    viscosityTitle: "Higher viscosity slows and thickens the flow",
    diffusion: "Diffusion",
    diffusionTitle: "Adjust how quickly color spreads through the field",
    palette: "Color field",
    paletteAria: "Choose a color palette",
    themeAurora: "Aurora",
    themeAuroraTitle: "Use the Aurora color palette",
    themePrism: "Prism",
    themePrismTitle: "Use the Prism color palette",
    themeEmber: "Ember",
    themeEmberTitle: "Use the Ember color palette",
    themeLagoon: "Lagoon",
    themeLagoonTitle: "Use the Lagoon color palette",
    effects: "Atmosphere",
    glow: "Soft glow",
    glowDetail: "Luminous edge bloom",
    glowTitle: "Toggle the soft light bloom around fluid",
    vortex: "Vortex brush",
    vortexDetail: "Curl flow around each stroke",
    vortexTitle: "Add a swirling force to brush strokes",
    autoFlow: "Ambient current",
    autoFlowDetail: "A slow, self-guided drift",
    autoFlowTitle: "Toggle the automatic fluid flow preset",
    resetCanvas: "Reset canvas",
    resetTitle: "Clear the fluid field",
    resetNote: "A clean surface, whenever you need one.",
    canvasOverline: "SIMULATION CANVAS",
    canvasTitle: "Fluid field",
    gridLabel: "GRID",
    fpsLabel: "FPS",
    pause: "Pause",
    resume: "Resume",
    pauseTitle: "Pause the fluid simulation",
    resumeTitle: "Resume the fluid simulation",
    canvasAria: "Interactive fluid simulation. Drag to paint with color.",
    canvasLive: "LIVE FIELD",
    dragHint: "Click and drag to pour color",
    simulationRunning: "Simulation running",
    simulationPaused: "Simulation paused",
    localRendering: "LOCAL RENDERING  ·  NO DATA LEAVES YOUR DEVICE",
    footerMade: "AETHER FLUID LAB",
    footerLine: "A little order inside the beautiful mess.",
    dismissErrorTitle: "Dismiss this message",
    workspaceAria: "Fluid simulation workspace",
    brandAria: "Aether Fluid Lab home",
    canvasUnavailable: "Canvas 2D is unavailable in this browser. Try a current version of Edge, Chrome, or Firefox.",
    simulationFailure: "The simulation stopped after a rendering issue. Reset the canvas to try again."
  },
  zh: {
    pageTitle: "Aether — 2D 流体实验室",
    brandCaption: "关于流动的一次小小研究",
    liveSimulation: "实时模拟",
    switchLanguageTitle: "切换至英文",
    eyebrow: "交互物理 / 01",
    headingLead: "让色彩",
    headingAccent: "自由流动。",
    introDescription: "涂抹一股水流，看色彩蔓延、回旋，找到自己的方向。",
    introNote: "每一笔，都会成为流动系统的一部分。",
    noteIndex: "实验手记 / 001",
    panelKicker: "创作工具",
    controls: "控制面板",
    brushSection: "画笔与流动",
    brushSize: "画笔大小",
    brushSizeTitle: "调整每一笔画的直径",
    flowForce: "流动力度",
    flowForceTitle: "调整画笔注入流体的动量",
    viscosity: "粘度",
    viscosityTitle: "粘度越高，流动越缓慢、浓稠",
    diffusion: "扩散速率",
    diffusionTitle: "调整色彩在流体中的扩散速度",
    palette: "色彩场",
    paletteAria: "选择配色方案",
    themeAurora: "极光",
    themeAuroraTitle: "使用极光配色",
    themePrism: "棱镜",
    themePrismTitle: "使用棱镜配色",
    themeEmber: "余烬",
    themeEmberTitle: "使用余烬配色",
    themeLagoon: "潟湖",
    themeLagoonTitle: "使用潟湖配色",
    effects: "氛围效果",
    glow: "柔和辉光",
    glowDetail: "为流体边缘添加光晕",
    glowTitle: "开关流体周围的柔和光晕",
    vortex: "涡旋画笔",
    vortexDetail: "让流体沿笔触卷曲",
    vortexTitle: "为画笔笔触添加旋涡力量",
    autoFlow: "环境流动",
    autoFlowDetail: "缓慢、自发的流动预设",
    autoFlowTitle: "开关自动流体流动预设",
    resetCanvas: "重置画布",
    resetTitle: "清除流体画布",
    resetNote: "随时恢复一片干净画布。",
    canvasOverline: "模拟画布",
    canvasTitle: "流体场",
    gridLabel: "网格",
    fpsLabel: "帧率",
    pause: "暂停",
    resume: "继续",
    pauseTitle: "暂停流体模拟",
    resumeTitle: "继续流体模拟",
    canvasAria: "可交互的流体模拟画布，拖动即可涂抹色彩。",
    canvasLive: "实时流体场",
    dragHint: "按住并拖动，倾注色彩",
    simulationRunning: "模拟运行中",
    simulationPaused: "模拟已暂停",
    localRendering: "本地渲染  ·  数据不会离开你的设备",
    footerMade: "AETHER 流体实验室",
    footerLine: "在流动的美妙混沌中，寻找一丝秩序。",
    dismissErrorTitle: "关闭此提示",
    workspaceAria: "流体模拟工作区",
    brandAria: "Aether 流体实验室主页",
    canvasUnavailable: "当前浏览器不支持 Canvas 2D。请尝试使用新版 Edge、Chrome 或 Firefox。",
    simulationFailure: "渲染出现问题，模拟已停止。请重置画布后重试。"
  }
};

const palettes: Record<ThemeId, Palette> = {
  aurora: {
    accent: "#75e5c0",
    colors: [
      { r: 55, g: 247, b: 191 },
      { r: 74, g: 174, b: 255 },
      { r: 187, g: 103, b: 255 }
    ]
  },
  prism: {
    accent: "#c591ff",
    colors: [
      { r: 37, g: 236, b: 255 },
      { r: 246, g: 92, b: 191 },
      { r: 255, g: 214, b: 101 }
    ]
  },
  ember: {
    accent: "#ff9b65",
    colors: [
      { r: 255, g: 105, b: 58 },
      { r: 255, g: 184, b: 69 },
      { r: 239, g: 76, b: 111 }
    ]
  },
  lagoon: {
    accent: "#65dff3",
    colors: [
      { r: 66, g: 231, b: 255 },
      { r: 86, g: 144, b: 255 },
      { r: 124, g: 238, b: 205 }
    ]
  }
};

const clamp = (value: number, min: number, max: number): number => Math.max(min, Math.min(max, value));

function getElement<T extends HTMLElement>(id: string): T {
  const element = document.getElementById(id);
  if (!(element instanceof HTMLElement)) {
    throw new Error(`Required interface element "${id}" was not found.`);
  }
  return element as T;
}

function createFields(size: number): FluidFields {
  return {
    u: new Float32Array(size),
    v: new Float32Array(size),
    u0: new Float32Array(size),
    v0: new Float32Array(size),
    red: new Float32Array(size),
    green: new Float32Array(size),
    blue: new Float32Array(size),
    red0: new Float32Array(size),
    green0: new Float32Array(size),
    blue0: new Float32Array(size),
    pressure: new Float32Array(size),
    divergence: new Float32Array(size)
  };
}

class FluidSolver {
  private fields: FluidFields;
  private viscosity = 0.24;
  private diffusion = 0.36;
  private disposed = false;
  private readonly iterations = 6;
  private readonly dyeFade = 0.994;

  constructor(public nx: number, public ny: number) {
    this.nx = Math.max(48, Math.floor(nx));
    this.ny = Math.max(40, Math.floor(ny));
    this.fields = createFields((this.nx + 2) * (this.ny + 2));
  }

  get cellCount(): number {
    return this.nx * this.ny;
  }

  get disposedState(): boolean {
    return this.disposed;
  }

  setDamping(viscosity: number, diffusion: number): void {
    this.viscosity = clamp(viscosity, 0, 1);
    this.diffusion = clamp(diffusion, 0, 1);
  }

  resize(nx: number, ny: number): void {
    if (this.disposed) return;
    const nextWidth = Math.max(48, Math.floor(nx));
    const nextHeight = Math.max(40, Math.floor(ny));
    if (nextWidth === this.nx && nextHeight === this.ny) return;

    const previous = this.fields;
    const oldWidth = this.nx;
    const oldHeight = this.ny;
    this.nx = nextWidth;
    this.ny = nextHeight;
    this.fields = createFields((this.nx + 2) * (this.ny + 2));
    for (const name of ["u", "v", "red", "green", "blue"] as const) {
      this.resample(previous[name], this.fields[name], oldWidth, oldHeight, this.nx, this.ny);
    }
  }

  clear(): void {
    if (this.disposed) return;
    for (const field of Object.values(this.fields)) field.fill(0);
  }

  inject(x: number, y: number, radius: number, color: Color, forceX: number, forceY: number, strength: number, vortex: boolean): void {
    if (this.disposed) return;
    const centerX = clamp(x, 1, this.nx);
    const centerY = clamp(y, 1, this.ny);
    const brushRadius = clamp(radius, 1.5, Math.max(2, Math.min(this.nx, this.ny) * 0.2));
    const searchRadius = Math.ceil(brushRadius * (vortex ? 1.65 : 1));
    const minX = Math.max(1, Math.floor(centerX - searchRadius));
    const maxX = Math.min(this.nx, Math.ceil(centerX + searchRadius));
    const minY = Math.max(1, Math.floor(centerY - searchRadius));
    const maxY = Math.min(this.ny, Math.ceil(centerY + searchRadius));
    const radiusSquared = brushRadius * brushRadius;

    for (let j = minY; j <= maxY; j += 1) {
      for (let i = minX; i <= maxX; i += 1) {
        const dx = i - centerX;
        const dy = j - centerY;
        const distanceSquared = dx * dx + dy * dy;
        const index = this.index(i, j);
        if (distanceSquared <= radiusSquared) {
          const falloff = Math.exp((-distanceSquared / radiusSquared) * 2.1);
          this.fields.red[index] += (color.r / 255) * strength * falloff;
          this.fields.green[index] += (color.g / 255) * strength * falloff;
          this.fields.blue[index] += (color.b / 255) * strength * falloff;
          this.fields.u[index] += forceX * falloff;
          this.fields.v[index] += forceY * falloff;
        } else if (vortex && distanceSquared < brushRadius * brushRadius * 2.72) {
          const distance = Math.sqrt(distanceSquared) || 1;
          const swirl = Math.exp(-distance / (brushRadius * 1.7)) * strength * 0.035;
          this.fields.u[index] += (-dy / distance) * swirl;
          this.fields.v[index] += (dx / distance) * swirl;
        }
      }
    }
  }

  step(dt: number): void {
    if (this.disposed) return;
    const { u, v, u0, v0, red, green, blue, red0, green0, blue0, pressure, divergence } = this.fields;
    const viscosityAmount = dt * 0.00105 * this.viscosity * this.viscosity * this.nx * this.ny;
    const diffusionAmount = dt * 0.00125 * this.diffusion * this.diffusion * this.nx * this.ny;
    const inverseScale = 1 / Math.min(this.nx, this.ny);
    const scale = Math.min(this.nx, this.ny);
    const dtX = dt * this.nx;
    const dtY = dt * this.ny;

    this.diffuse(1, u0, u, viscosityAmount, 1 + 4 * viscosityAmount);
    this.diffuse(2, v0, v, viscosityAmount, 1 + 4 * viscosityAmount);
    this.project(u0, v0, pressure, divergence, inverseScale, scale);
    this.advect(1, u, u0, u0, v0, dtX, dtY);
    this.advect(2, v, v0, u0, v0, dtX, dtY);
    this.project(u, v, pressure, divergence, inverseScale, scale);

    this.diffuse(0, red0, red, diffusionAmount, 1 + 4 * diffusionAmount);
    this.diffuse(0, green0, green, diffusionAmount, 1 + 4 * diffusionAmount);
    this.diffuse(0, blue0, blue, diffusionAmount, 1 + 4 * diffusionAmount);
    this.advect(0, red, red0, u, v, dtX, dtY);
    this.advect(0, green, green0, u, v, dtX, dtY);
    this.advect(0, blue, blue0, u, v, dtX, dtY);

    const fade = Math.pow(this.dyeFade, dt * 60);
    for (let j = 1; j <= this.ny; j += 1) {
      for (let i = 1; i <= this.nx; i += 1) {
        const index = this.index(i, j);
        red[index] = Math.max(0, red[index] * fade);
        green[index] = Math.max(0, green[index] * fade);
        blue[index] = Math.max(0, blue[index] * fade);
        u[index] *= 0.999;
        v[index] *= 0.999;
      }
    }
  }

  writeImageData(pixels: Uint8ClampedArray): void {
    if (this.disposed) return;
    const { red, green, blue } = this.fields;
    for (let j = 1; j <= this.ny; j += 1) {
      for (let i = 1; i <= this.nx; i += 1) {
        const sourceIndex = this.index(i, j);
        const pixelIndex = ((j - 1) * this.nx + i - 1) * 4;
        const redValue = Math.max(0, red[sourceIndex]);
        const greenValue = Math.max(0, green[sourceIndex]);
        const blueValue = Math.max(0, blue[sourceIndex]);
        const total = redValue + greenValue + blueValue;
        if (total < 0.006) {
          pixels[pixelIndex] = 0;
          pixels[pixelIndex + 1] = 0;
          pixels[pixelIndex + 2] = 0;
          pixels[pixelIndex + 3] = 0;
          continue;
        }

        const opacity = 1 - Math.exp(-total * 0.31);
        pixels[pixelIndex] = (redValue / total) * 255;
        pixels[pixelIndex + 1] = (greenValue / total) * 255;
        pixels[pixelIndex + 2] = (blueValue / total) * 255;
        pixels[pixelIndex + 3] = Math.min(238, opacity * 255);
      }
    }
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    const empty = new Float32Array(0);
    this.fields = {
      u: empty,
      v: empty,
      u0: empty,
      v0: empty,
      red: empty,
      green: empty,
      blue: empty,
      red0: empty,
      green0: empty,
      blue0: empty,
      pressure: empty,
      divergence: empty
    };
    this.nx = 0;
    this.ny = 0;
  }

  private index(x: number, y: number): number {
    return x + (this.nx + 2) * y;
  }

  private resample(source: Float32Array, destination: Float32Array, oldWidth: number, oldHeight: number, newWidth: number, newHeight: number): void {
    const oldStride = oldWidth + 2;
    const newStride = newWidth + 2;
    for (let y = 1; y <= newHeight; y += 1) {
      const sourceY = 1 + ((y - 1) / Math.max(1, newHeight - 1)) * Math.max(0, oldHeight - 1);
      const y0 = Math.floor(sourceY);
      const y1 = Math.min(oldHeight, y0 + 1);
      const weightY = sourceY - y0;
      for (let x = 1; x <= newWidth; x += 1) {
        const sourceX = 1 + ((x - 1) / Math.max(1, newWidth - 1)) * Math.max(0, oldWidth - 1);
        const x0 = Math.floor(sourceX);
        const x1 = Math.min(oldWidth, x0 + 1);
        const weightX = sourceX - x0;
        const topLeft = source[x0 + oldStride * y0];
        const topRight = source[x1 + oldStride * y0];
        const bottomLeft = source[x0 + oldStride * y1];
        const bottomRight = source[x1 + oldStride * y1];
        const top = topLeft + (topRight - topLeft) * weightX;
        const bottom = bottomLeft + (bottomRight - bottomLeft) * weightX;
        destination[x + newStride * y] = top + (bottom - top) * weightY;
      }
    }
  }

  private diffuse(boundary: FieldKind, destination: Float32Array, source: Float32Array, amount: number, denominator: number): void {
    this.linearSolve(boundary, destination, source, amount, denominator);
  }

  private linearSolve(boundary: FieldKind, solution: Float32Array, source: Float32Array, amount: number, denominator: number): void {
    if (amount <= 0.000001) {
      solution.set(source);
      this.setBoundary(boundary, solution);
      return;
    }
    const stride = this.nx + 2;
    for (let iteration = 0; iteration < this.iterations; iteration += 1) {
      for (let j = 1; j <= this.ny; j += 1) {
        const row = stride * j;
        for (let i = 1; i <= this.nx; i += 1) {
          const index = row + i;
          solution[index] = (source[index] + amount * (solution[index - 1] + solution[index + 1] + solution[index - stride] + solution[index + stride])) / denominator;
        }
      }
      this.setBoundary(boundary, solution);
    }
  }

  private project(u: Float32Array, v: Float32Array, pressure: Float32Array, divergence: Float32Array, inverseScale: number, scale: number): void {
    const stride = this.nx + 2;
    pressure.fill(0);
    divergence.fill(0);
    for (let j = 1; j <= this.ny; j += 1) {
      const row = stride * j;
      for (let i = 1; i <= this.nx; i += 1) {
        const index = row + i;
        divergence[index] = -0.5 * (u[index + 1] - u[index - 1] + v[index + stride] - v[index - stride]) * inverseScale;
      }
    }
    this.setBoundary(0, divergence);
    this.setBoundary(0, pressure);
    this.linearSolve(0, pressure, divergence, 1, 4);
    for (let j = 1; j <= this.ny; j += 1) {
      const row = stride * j;
      for (let i = 1; i <= this.nx; i += 1) {
        const index = row + i;
        u[index] -= 0.5 * scale * (pressure[index + 1] - pressure[index - 1]);
        v[index] -= 0.5 * scale * (pressure[index + stride] - pressure[index - stride]);
      }
    }
    this.setBoundary(1, u);
    this.setBoundary(2, v);
  }

  private advect(boundary: FieldKind, destination: Float32Array, source: Float32Array, u: Float32Array, v: Float32Array, dtX: number, dtY: number): void {
    const stride = this.nx + 2;
    for (let j = 1; j <= this.ny; j += 1) {
      const row = stride * j;
      for (let i = 1; i <= this.nx; i += 1) {
        const index = row + i;
        const sourceX = clamp(i - dtX * u[index], 0.5, this.nx + 0.5);
        const sourceY = clamp(j - dtY * v[index], 0.5, this.ny + 0.5);
        const left = Math.floor(sourceX);
        const right = left + 1;
        const top = Math.floor(sourceY);
        const bottom = top + 1;
        const weightX = sourceX - left;
        const weightY = sourceY - top;
        const topIndex = top * stride;
        const bottomIndex = bottom * stride;
        destination[index] = (1 - weightX) * ((1 - weightY) * source[left + topIndex] + weightY * source[left + bottomIndex])
          + weightX * ((1 - weightY) * source[right + topIndex] + weightY * source[right + bottomIndex]);
      }
    }
    this.setBoundary(boundary, destination);
  }

  private setBoundary(kind: FieldKind, field: Float32Array): void {
    const stride = this.nx + 2;
    for (let i = 1; i <= this.nx; i += 1) {
      field[i] = kind === 2 ? -field[i + stride] : field[i + stride];
      field[i + stride * (this.ny + 1)] = kind === 2 ? -field[i + stride * this.ny] : field[i + stride * this.ny];
    }
    for (let j = 1; j <= this.ny; j += 1) {
      const row = j * stride;
      field[row] = kind === 1 ? -field[row + 1] : field[row + 1];
      field[row + this.nx + 1] = kind === 1 ? -field[row + this.nx] : field[row + this.nx];
    }
    field[0] = 0.5 * (field[1] + field[stride]);
    field[this.nx + 1] = 0.5 * (field[this.nx] + field[this.nx + 1 + stride]);
    field[stride * (this.ny + 1)] = 0.5 * (field[stride * (this.ny + 1) + 1] + field[stride * this.ny]);
    field[stride * (this.ny + 1) + this.nx + 1] = 0.5 * (field[stride * (this.ny + 1) + this.nx] + field[stride * this.ny + this.nx + 1]);
  }
}

class FluidRenderer {
  private readonly canvasContext: CanvasRenderingContext2D;
  private readonly buffer = document.createElement("canvas");
  private readonly bufferContext: CanvasRenderingContext2D;
  private imageData: ImageData | null = null;
  private width = 0;
  private height = 0;
  private disposed = false;

  constructor(private readonly canvas: HTMLCanvasElement) {
    const canvasContext = canvas.getContext("2d", { alpha: true, desynchronized: true });
    const bufferContext = this.buffer.getContext("2d", { alpha: true });
    if (!canvasContext || !bufferContext) throw new Error("Canvas 2D context creation failed.");
    this.canvasContext = canvasContext;
    this.bufferContext = bufferContext;
  }

  resize(width: number, height: number, pixelRatio: number, gridWidth: number, gridHeight: number): void {
    if (this.disposed || width <= 0 || height <= 0) return;
    this.width = width;
    this.height = height;
    const pixelWidth = Math.max(1, Math.round(width * pixelRatio));
    const pixelHeight = Math.max(1, Math.round(height * pixelRatio));
    if (this.canvas.width !== pixelWidth || this.canvas.height !== pixelHeight) {
      this.canvas.width = pixelWidth;
      this.canvas.height = pixelHeight;
    }
    this.canvasContext.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    this.canvasContext.imageSmoothingEnabled = true;
    if (this.buffer.width !== gridWidth || this.buffer.height !== gridHeight || !this.imageData) {
      this.buffer.width = gridWidth;
      this.buffer.height = gridHeight;
      this.imageData = this.bufferContext.createImageData(gridWidth, gridHeight);
    }
  }

  draw(solver: FluidSolver, glow: boolean): void {
    if (this.disposed || !this.imageData || solver.disposedState) return;
    solver.writeImageData(this.imageData.data);
    this.bufferContext.putImageData(this.imageData, 0, 0);
    const context = this.canvasContext;
    context.save();
    context.clearRect(0, 0, this.width, this.height);
    context.globalCompositeOperation = "screen";
    if (glow) {
      context.filter = `blur(${clamp(this.width / 90, 10, 22)}px)`;
      context.globalAlpha = 0.72;
      context.drawImage(this.buffer, 0, 0, this.width, this.height);
    }
    context.filter = "none";
    context.globalAlpha = 0.94;
    context.drawImage(this.buffer, 0, 0, this.width, this.height);
    context.restore();
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.imageData = null;
    this.buffer.width = 1;
    this.buffer.height = 1;
    this.canvas.width = 1;
    this.canvas.height = 1;
    this.width = 0;
    this.height = 0;
  }
}

class FluidApp {
  private readonly abortController = new AbortController();
  private readonly canvas: HTMLCanvasElement;
  private readonly stage: HTMLElement;
  private readonly languageButton: HTMLButtonElement;
  private readonly languageLabel: HTMLElement;
  private readonly gridValue: HTMLElement;
  private readonly fpsValue: HTMLElement;
  private readonly coordinateValue: HTMLElement;
  private readonly statusValue: HTMLElement;
  private readonly pauseLabel: HTMLElement;
  private readonly pauseButton: HTMLButtonElement;
  private readonly errorBanner: HTMLElement;
  private readonly errorMessage: HTMLElement;
  private resizeObserver: ResizeObserver | null = null;
  private solver: FluidSolver | null = null;
  private renderer: FluidRenderer | null = null;
  private frameHandle = 0;
  private lastFrameTime = 0;
  private accumulatedTime = 0;
  private simulationTime = 0;
  private fpsWindowStart = 0;
  private fpsFrameCount = 0;
  private paused = false;
  private visible = !document.hidden;
  private destroyed = false;
  private painting = false;
  private activePointerId: number | null = null;
  private lastPointer: { x: number; y: number } | null = null;
  private currentColorIndex = 0;
  private language: Language = "en";
  private theme: ThemeId = "aurora";
  private currentError: ErrorKey | null = null;
  private brushSize = 42;
  private flowForce = 0.68;
  private viscosity = 0.24;
  private diffusion = 0.36;
  private glowEnabled = true;
  private vortexEnabled = false;
  private autoFlowEnabled = true;

  constructor() {
    this.canvas = getElement<HTMLCanvasElement>("fluidCanvas");
    this.stage = getElement<HTMLElement>("canvasStage");
    this.languageButton = getElement<HTMLButtonElement>("languageToggle");
    this.languageLabel = getElement<HTMLElement>("languageLabel");
    this.gridValue = getElement<HTMLElement>("gridValue");
    this.fpsValue = getElement<HTMLElement>("fpsValue");
    this.coordinateValue = getElement<HTMLElement>("coordinateValue");
    this.statusValue = getElement<HTMLElement>("simulationStatus");
    this.pauseLabel = getElement<HTMLElement>("pauseLabel");
    this.pauseButton = getElement<HTMLButtonElement>("pauseButton");
    this.errorBanner = getElement<HTMLElement>("errorBanner");
    this.errorMessage = getElement<HTMLElement>("errorMessage");
    this.bindEvents();
    this.applyLanguage();

    try {
      this.renderer = new FluidRenderer(this.canvas);
      const initialGrid = this.getGridSize();
      this.solver = new FluidSolver(initialGrid.width, initialGrid.height);
      this.solver.setDamping(this.viscosity, this.diffusion);
      if (typeof ResizeObserver !== "undefined") {
        this.resizeObserver = new ResizeObserver(() => this.resize());
        this.resizeObserver.observe(this.stage);
      } else {
        window.addEventListener("resize", () => this.resize(), { signal: this.abortController.signal });
      }
      this.resize();
      this.updateTheme();
      this.updateReadouts();
      this.scheduleFrame();
    } catch (error) {
      console.error("Aether failed to initialize.", error);
      const rendererWasCreated = this.renderer !== null;
      this.resizeObserver?.disconnect();
      this.resizeObserver = null;
      this.renderer?.dispose();
      this.renderer = null;
      this.solver?.dispose();
      this.solver = null;
      if (this.frameHandle) cancelAnimationFrame(this.frameHandle);
      this.frameHandle = 0;
      this.showError(rendererWasCreated ? "simulationFailure" : "canvasUnavailable");
    }
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    this.abortController.abort();
    this.resizeObserver?.disconnect();
    if (this.frameHandle) cancelAnimationFrame(this.frameHandle);
    this.frameHandle = 0;
    this.renderer?.dispose();
    this.renderer = null;
    this.solver?.dispose();
    this.solver = null;
    this.lastPointer = null;
  }

  private bindEvents(): void {
    const signal = this.abortController.signal;
    this.languageButton.addEventListener("click", () => this.toggleLanguage(), { signal });
    getElement<HTMLButtonElement>("resetButton").addEventListener("click", () => this.reset(), { signal });
    this.pauseButton.addEventListener("click", () => this.togglePause(), { signal });
    getElement<HTMLButtonElement>("dismissError").addEventListener("click", () => this.clearError(), { signal });
    getElement<HTMLButtonElement>("glowToggle").addEventListener("click", () => {
      this.glowEnabled = !this.glowEnabled;
      this.syncSwitch("glowToggle", this.glowEnabled);
    }, { signal });
    getElement<HTMLButtonElement>("vortexToggle").addEventListener("click", () => {
      this.vortexEnabled = !this.vortexEnabled;
      this.syncSwitch("vortexToggle", this.vortexEnabled);
    }, { signal });
    getElement<HTMLButtonElement>("autoFlowToggle").addEventListener("click", () => {
      this.autoFlowEnabled = !this.autoFlowEnabled;
      this.syncSwitch("autoFlowToggle", this.autoFlowEnabled);
    }, { signal });

    this.bindRange("brushSize", (value) => {
      this.brushSize = value;
      getElement<HTMLOutputElement>("brushSizeValue").value = `${Math.round(value)} px`;
      getElement<HTMLOutputElement>("brushSizeValue").textContent = `${Math.round(value)} px`;
    });
    this.bindRange("flowForce", (value) => {
      this.flowForce = value / 100;
      getElement<HTMLOutputElement>("flowForceValue").value = `${Math.round(value)}%`;
      getElement<HTMLOutputElement>("flowForceValue").textContent = `${Math.round(value)}%`;
    });
    this.bindRange("viscosity", (value) => {
      this.viscosity = value / 100;
      this.solver?.setDamping(this.viscosity, this.diffusion);
      getElement<HTMLOutputElement>("viscosityValue").value = `${Math.round(value)}%`;
      getElement<HTMLOutputElement>("viscosityValue").textContent = `${Math.round(value)}%`;
    });
    this.bindRange("diffusion", (value) => {
      this.diffusion = value / 100;
      this.solver?.setDamping(this.viscosity, this.diffusion);
      getElement<HTMLOutputElement>("diffusionValue").value = `${Math.round(value)}%`;
      getElement<HTMLOutputElement>("diffusionValue").textContent = `${Math.round(value)}%`;
    });

    document.querySelectorAll<HTMLButtonElement>("[data-theme]").forEach((button) => {
      button.addEventListener("click", () => {
        const selectedTheme = button.dataset.theme;
        if (selectedTheme && selectedTheme in palettes) {
          this.theme = selectedTheme as ThemeId;
          this.updateTheme();
        }
      }, { signal });
    });

    this.canvas.addEventListener("pointerdown", this.onPointerDown, { signal });
    this.canvas.addEventListener("pointermove", this.onPointerMove, { signal });
    this.canvas.addEventListener("pointerup", this.onPointerEnd, { signal });
    this.canvas.addEventListener("pointercancel", this.onPointerEnd, { signal });
    this.canvas.addEventListener("pointerleave", this.onPointerLeave, { signal });
    this.canvas.addEventListener("contextmenu", this.onContextMenu, { signal });
    this.canvas.addEventListener("keydown", this.onCanvasKeyDown, { signal });
    document.addEventListener("visibilitychange", this.onVisibilityChange, { signal });
    window.addEventListener("error", this.onWindowError, { signal });
    window.addEventListener("unhandledrejection", this.onUnhandledRejection, { signal });
  }

  private bindRange(id: string, onChange: (value: number) => void): void {
    const input = getElement<HTMLInputElement>(id);
    input.addEventListener("input", () => {
      const value = Number(input.value);
      if (Number.isFinite(value)) onChange(value);
    }, { signal: this.abortController.signal });
  }

  private toggleLanguage(): void {
    this.language = this.language === "en" ? "zh" : "en";
    this.applyLanguage();
  }

  private applyLanguage(): void {
    const text = messages[this.language];
    document.documentElement.lang = this.language === "zh" ? "zh-CN" : "en";
    document.title = text.pageTitle;
    document.querySelectorAll<HTMLElement>("[data-i18n]").forEach((element) => {
      const key = element.dataset.i18n as keyof Messages | undefined;
      if (key && key in text) element.textContent = text[key];
    });
    document.querySelectorAll<HTMLElement>("[data-i18n-title]").forEach((element) => {
      const key = element.dataset.i18nTitle as keyof Messages | undefined;
      if (key && key in text) element.title = text[key];
    });
    document.querySelectorAll<HTMLElement>("[data-i18n-aria]").forEach((element) => {
      const key = element.dataset.i18nAria as keyof Messages | undefined;
      if (key && key in text) element.setAttribute("aria-label", text[key]);
    });
    this.languageLabel.textContent = this.language === "en" ? "中文" : "English";
    this.syncPauseButton();
    if (this.currentError) this.errorMessage.textContent = text[this.currentError];
    this.updateStatus();
    this.updateCoordinates(this.lastPointer);
  }

  private updateTheme(): void {
    document.documentElement.style.setProperty("--theme-accent", palettes[this.theme].accent);
    document.documentElement.dataset.theme = this.theme;
    document.querySelectorAll<HTMLButtonElement>("[data-theme]").forEach((button) => {
      const selected = button.dataset.theme === this.theme;
      button.classList.toggle("is-selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
  }

  private updateReadouts(): void {
    this.gridValue.textContent = this.solver ? `${this.solver.nx} × ${this.solver.ny}` : "—";
    this.updateStatus();
  }

  private updateStatus(): void {
    this.statusValue.textContent = messages[this.language][this.paused ? "simulationPaused" : "simulationRunning"];
  }

  private syncPauseButton(): void {
    const labelKey = this.paused ? "resume" : "pause";
    const titleKey = this.paused ? "resumeTitle" : "pauseTitle";
    this.pauseLabel.textContent = messages[this.language][labelKey];
    this.pauseButton.title = messages[this.language][titleKey];
    this.pauseButton.setAttribute("aria-label", messages[this.language][titleKey]);
    this.pauseButton.setAttribute("aria-pressed", String(this.paused));
    this.pauseButton.classList.toggle("is-paused", this.paused);
  }

  private syncSwitch(id: string, enabled: boolean): void {
    const button = getElement<HTMLButtonElement>(id);
    button.classList.toggle("is-on", enabled);
    button.setAttribute("aria-checked", String(enabled));
  }

  private togglePause(): void {
    this.paused = !this.paused;
    this.syncPauseButton();
    this.updateStatus();
    if (this.paused) {
      if (this.frameHandle) cancelAnimationFrame(this.frameHandle);
      this.frameHandle = 0;
      return;
    }
    this.lastFrameTime = 0;
    this.scheduleFrame();
  }

  private reset(): void {
    this.solver?.clear();
    this.simulationTime = 0;
    this.clearError();
    this.stage.classList.remove("has-fluid-mark");
  }

  private showError(key: ErrorKey): void {
    this.currentError = key;
    this.errorMessage.textContent = messages[this.language][key];
    this.errorBanner.hidden = false;
    this.stage.classList.add("has-error");
  }

  private clearError(): void {
    this.currentError = null;
    this.errorBanner.hidden = true;
    this.stage.classList.remove("has-error");
  }

  private showRuntimeError(error: unknown): void {
    console.error("Aether encountered a simulation error.", error);
    this.paused = true;
    this.syncPauseButton();
    this.updateStatus();
    if (this.frameHandle) cancelAnimationFrame(this.frameHandle);
    this.frameHandle = 0;
    this.showError("simulationFailure");
  }

  private getGridSize(): { width: number; height: number } {
    const rect = this.stage.getBoundingClientRect();
    const ratio = rect.width > 0 && rect.height > 0 ? rect.width / rect.height : 1.5;
    const width = clamp(Math.round((rect.width || 960) / 5), 112, 256);
    let height = clamp(Math.round(width / ratio), 72, 184);
    let adjustedWidth = width;
    const maxCells = 42000;
    if (adjustedWidth * height > maxCells) {
      const scale = Math.sqrt(maxCells / (adjustedWidth * height));
      adjustedWidth = Math.max(96, Math.floor(adjustedWidth * scale));
      height = Math.max(64, Math.floor(height * scale));
    }
    return { width: adjustedWidth, height };
  }

  private resize(): void {
    if (this.destroyed || !this.solver || !this.renderer) return;
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const pixelRatio = clamp(window.devicePixelRatio || 1, 1, 2.5);
    const grid = this.getGridSize();
    this.solver.resize(grid.width, grid.height);
    this.renderer.resize(rect.width, rect.height, pixelRatio, this.solver.nx, this.solver.ny);
    this.gridValue.textContent = `${this.solver.nx} × ${this.solver.ny}`;
  }

  private getPointerPosition(event: PointerEvent): { x: number; y: number } | null {
    const rect = this.canvas.getBoundingClientRect();
    const solver = this.solver;
    if (!solver || rect.width <= 0 || rect.height <= 0) return null;
    return {
      x: 1 + clamp((event.clientX - rect.left) / rect.width, 0, 1) * Math.max(1, solver.nx - 1),
      y: 1 + clamp((event.clientY - rect.top) / rect.height, 0, 1) * Math.max(1, solver.ny - 1)
    };
  }

  private updateCoordinates(point: { x: number; y: number } | null): void {
    if (!point || !this.solver) {
      this.coordinateValue.textContent = "X 0.00   Y 0.00";
      return;
    }
    const x = clamp((point.x - 1) / Math.max(1, this.solver.nx - 1), 0, 1);
    const y = clamp((point.y - 1) / Math.max(1, this.solver.ny - 1), 0, 1);
    this.coordinateValue.textContent = this.language === "en"
      ? `X ${x.toFixed(2)}   Y ${y.toFixed(2)}`
      : `横 ${x.toFixed(2)}   纵 ${y.toFixed(2)}`;
  }

  private readonly onPointerDown = (event: PointerEvent): void => {
    if (event.button !== 0 || this.paused || !this.solver) return;
    event.preventDefault();
    this.painting = true;
    this.activePointerId = event.pointerId;
    this.currentColorIndex = (this.currentColorIndex + 1) % palettes[this.theme].colors.length;
    this.lastPointer = this.getPointerPosition(event);
    this.updateCoordinates(this.lastPointer);
    if (this.lastPointer) this.injectStroke(this.lastPointer, this.lastPointer);
    try {
      this.canvas.setPointerCapture(event.pointerId);
    } catch (error) {
      console.warn("Pointer capture was not available; continuing without it.", error);
    }
  };

  private readonly onPointerMove = (event: PointerEvent): void => {
    const point = this.getPointerPosition(event);
    this.updateCoordinates(point);
    if (!this.painting || this.activePointerId !== event.pointerId || !point) return;
    event.preventDefault();
    if (this.lastPointer) this.injectStroke(this.lastPointer, point);
    this.lastPointer = point;
  };

  private readonly onPointerEnd = (event: PointerEvent): void => {
    if (this.activePointerId !== event.pointerId) return;
    this.painting = false;
    this.activePointerId = null;
    this.lastPointer = null;
  };

  private readonly onPointerLeave = (): void => {
    if (!this.painting) this.updateCoordinates(null);
  };

  private readonly onContextMenu = (event: MouseEvent): void => event.preventDefault();

  private readonly onCanvasKeyDown = (event: KeyboardEvent): void => {
    if (event.code === "Space") {
      event.preventDefault();
      this.togglePause();
    } else if (event.key.toLowerCase() === "r") {
      this.reset();
    }
  };

  private readonly onVisibilityChange = (): void => {
    this.visible = !document.hidden;
    if (!this.visible) {
      if (this.frameHandle) cancelAnimationFrame(this.frameHandle);
      this.frameHandle = 0;
      this.lastFrameTime = 0;
      return;
    }
    this.scheduleFrame();
  };

  private readonly onWindowError = (event: ErrorEvent): void => {
    this.showRuntimeError(event.error ?? event.message);
  };

  private readonly onUnhandledRejection = (event: PromiseRejectionEvent): void => {
    this.showRuntimeError(event.reason);
  };

  private injectStroke(from: { x: number; y: number }, to: { x: number; y: number }): void {
    const solver = this.solver;
    if (!solver) return;
    const deltaX = to.x - from.x;
    const deltaY = to.y - from.y;
    const distance = Math.hypot(deltaX, deltaY);
    const brushRadius = (this.brushSize / Math.max(1, this.canvas.clientWidth)) * solver.nx * 0.5;
    const spacing = Math.max(1.3, brushRadius * 0.38);
    const samples = Math.max(1, Math.ceil(distance / spacing));
    const palette = palettes[this.theme];
    const color = palette.colors[this.currentColorIndex % palette.colors.length];
    const velocityScale = this.flowForce * 0.11;
    const forceX = deltaX * velocityScale;
    const forceY = deltaY * velocityScale;
    const strength = 0.92 + this.flowForce * 0.3;

    for (let sample = 0; sample <= samples; sample += 1) {
      const progress = sample / samples;
      solver.inject(
        from.x + deltaX * progress,
        from.y + deltaY * progress,
        brushRadius,
        color,
        forceX / samples,
        forceY / samples,
        strength / Math.max(1, samples * 0.72),
        this.vortexEnabled
      );
    }
    this.stage.classList.add("has-fluid-mark");
  }

  private applyAmbientFlow(dt: number): void {
    const solver = this.solver;
    if (!solver || !this.autoFlowEnabled) return;
    const palette = palettes[this.theme];
    const phase = this.simulationTime * 0.34;
    const normalizedDt = dt * 60;
    for (let emitter = 0; emitter < 3; emitter += 1) {
      const offset = emitter * (Math.PI * 2 / 3);
      const angle = phase + offset;
      const horizontalRadius = solver.nx * 0.26;
      const verticalRadius = solver.ny * 0.3;
      const x = solver.nx * 0.5 + Math.cos(angle) * horizontalRadius;
      const y = solver.ny * 0.5 + Math.sin(angle * 0.82) * verticalRadius;
      const velocityX = -Math.sin(angle) * 0.04 * normalizedDt;
      const velocityY = Math.cos(angle * 0.82) * 0.026 * normalizedDt;
      solver.inject(x, y, 2.8, palette.colors[emitter], velocityX, velocityY, 0.065 * normalizedDt, this.vortexEnabled);
    }
  }

  private scheduleFrame(): void {
    if (this.destroyed || this.paused || !this.visible || !this.solver || this.frameHandle) return;
    this.frameHandle = requestAnimationFrame(this.renderFrame);
  }

  private readonly renderFrame = (now: number): void => {
    this.frameHandle = 0;
    if (this.destroyed || this.paused || !this.visible || !this.solver || !this.renderer) return;
    try {
      const elapsed = this.lastFrameTime === 0 ? 1 / 60 : clamp((now - this.lastFrameTime) / 1000, 0, 0.04);
      this.lastFrameTime = now;
      this.accumulatedTime += elapsed;
      const fixedStep = 1 / 60;
      let steps = 0;
      while (this.accumulatedTime >= fixedStep && steps < 3) {
        this.simulationTime += fixedStep;
        this.applyAmbientFlow(fixedStep);
        this.solver.step(fixedStep);
        this.accumulatedTime -= fixedStep;
        steps += 1;
      }
      if (steps === 3 && this.accumulatedTime > fixedStep * 2) this.accumulatedTime = fixedStep * 2;
      this.renderer.draw(this.solver, this.glowEnabled);
      this.updateFrameRate(now);
      this.scheduleFrame();
    } catch (error) {
      this.showRuntimeError(error);
    }
  };

  private updateFrameRate(now: number): void {
    this.fpsFrameCount += 1;
    if (this.fpsWindowStart === 0) this.fpsWindowStart = now;
    const interval = now - this.fpsWindowStart;
    if (interval >= 500) {
      this.fpsValue.textContent = String(Math.round((this.fpsFrameCount * 1000) / interval));
      this.fpsFrameCount = 0;
      this.fpsWindowStart = now;
    }
  }
}

let activeApp: FluidApp | null = null;

function boot(): void {
  activeApp?.destroy();
  try {
    activeApp = new FluidApp();
  } catch (error) {
    console.error("Aether could not start.", error);
    const banner = document.getElementById("errorBanner");
    const message = document.getElementById("errorMessage");
    if (banner && message) {
      const language: Language = document.documentElement.lang === "zh-CN" ? "zh" : "en";
      message.textContent = messages[language].simulationFailure;
      banner.hidden = false;
    }
  }
}

window.addEventListener("pagehide", () => {
  activeApp?.destroy();
  activeApp = null;
});

window.addEventListener("pageshow", (event) => {
  if (event.persisted && !activeApp) boot();
});

boot();
